package com.factura_ariel_aguirre.facturacion_ariel_aguirre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionArielAguirreApplicationTests {

	@Test
	void contextLoads() {
	}

}
